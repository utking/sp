<p><?php echo $this->getContent() ?></p>
<div>
    <div class="title">Список закупок товаров</div><br>
    <table class="table table-bordered table-condensed cat_table">
    <?php foreach ($this->view->categories as $category) { ?>
        <tr>
            <td class="cat_title">
                <?= $category->title ?><br>
                <?php echo $this->tag->linkTo(array(
                    '/categories/view/' . $category->id, 
                    'text' => 
                    (strlen($category->img) > 0 ? ('<img class="cat_img" src="data:image/jpeg;charset=utf-8;base64,' . $category->img . '">') : ('<img class="cat_img" src="/img/noimage.jpg">')))); ?>
            </td>
            <td class="cat_desc"><?= $category->desc ?></td>
            <td class="cat_products_count">Товаров в закупке - <?= count(Product::find(array('conditions' => 'category_id = ?1', 'bind' => array( 1 => $category->id)))) ?></td>
        </tr>
    <?php } ?>
    </table>
</div>